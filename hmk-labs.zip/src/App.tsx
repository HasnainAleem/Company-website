/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { WhyUsSection } from './components/WhyUsSection';
import { ProcessSection } from './components/ProcessSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { AboutModal } from './components/AboutModal';
import { ProjectInquiryModal } from './components/ProjectInquiryModal';
import { ServiceItem } from './types';
import { SERVICES_DATA } from './data/content';

export default function App() {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [aboutModalOpen, setAboutModalOpen] = useState(false);
  const [projectInquiryOpen, setProjectInquiryOpen] = useState(false);
  const [initialServiceForInquiry, setInitialServiceForInquiry] = useState<string | undefined>(undefined);

  const handleOpenContact = () => {
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleStartProject = (serviceTitle?: string) => {
    setInitialServiceForInquiry(serviceTitle);
    setProjectInquiryOpen(true);
  };

  const handleSelectServiceById = (id: string) => {
    const found = SERVICES_DATA.find((s) => s.id === id);
    if (found) {
      setSelectedService(found);
    }
  };

  return (
    <div id="hmk-labs-app" className="min-h-screen bg-white text-[#202124] flex flex-col font-sans">
      {/* 1. Navbar */}
      <Navbar onOpenContact={handleOpenContact} />

      {/* Main Content Flow */}
      <main className="flex-1">
        {/* 2. Hero Section */}
        <Hero onStartProject={() => handleStartProject()} />

        {/* 3. About / Introduction Section */}
        <AboutSection onOpenAboutModal={() => setAboutModalOpen(true)} />

        {/* 4. Services Section (4 core cards) */}
        <ServicesSection onSelectService={(service) => setSelectedService(service)} />

        {/* 5. Why HMK Labs Section */}
        <WhyUsSection />

        {/* 6. Simple Process Section (From Idea to Reality) */}
        <ProcessSection />

        {/* 7. Contact CTA & Section */}
        <ContactSection />
      </main>

      {/* 8. Footer */}
      <Footer
        onSelectServiceById={handleSelectServiceById}
        onOpenAboutModal={() => setAboutModalOpen(true)}
        onOpenContact={handleOpenContact}
      />

      {/* Modals & Dialogs */}
      <ServiceDetailModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        onStartProjectForService={(title) => handleStartProject(title)}
      />

      <AboutModal
        isOpen={aboutModalOpen}
        onClose={() => setAboutModalOpen(false)}
        onStartProject={() => {
          setAboutModalOpen(false);
          handleStartProject();
        }}
      />

      <ProjectInquiryModal
        isOpen={projectInquiryOpen}
        onClose={() => {
          setProjectInquiryOpen(false);
          setInitialServiceForInquiry(undefined);
        }}
        initialService={initialServiceForInquiry}
      />
    </div>
  );
}
