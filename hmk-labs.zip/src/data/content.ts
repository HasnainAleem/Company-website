import { ServiceItem, PillarItem, ProcessStep } from '../types';

export const HERO_DATA = {
  headline: "Building Technology. Creating Possibilities.",
  subheadline: "HMK Labs is a technology company building modern software, AI-powered solutions and digital experiences that help businesses grow and operate smarter.",
  ctaPrimary: "Start a Project →",
  ctaSecondary: "Explore Services ↓",
};

export const ABOUT_DATA = {
  heading: "Technology Built With Purpose.",
  description: "At HMK Labs, we combine software engineering, artificial intelligence and modern design to turn ideas into reliable digital products. From websites and applications to intelligent business solutions, we focus on building technology that delivers real value.",
  linkText: "More About HMK Labs →",
  pillarsSummary: [
    { label: "Engineering Excellence", desc: "Clean architecture, high test coverage, and scalable codebases." },
    { label: "AI First Thinking", desc: "Pragmatic machine intelligence designed for real enterprise outcomes." },
    { label: "Human Centered", desc: "Intuitive interfaces where sophisticated engineering feels seamless." }
  ],
  extendedDetails: {
    mission: "To engineer dependable, elegant, and future-resilient digital systems that empower ambitious businesses to solve real-world problems and outpace competition.",
    approach: "We eschew vanity tech stacks in favor of high-impact, performant, and maintainable software. Every line of code is written with scalability, security, and user delight in mind.",
    values: [
      "No needless bloat or premature complexity",
      "Direct engineer-to-client collaboration",
      "Transparent sprint velocity and milestone tracking",
      "Obsessive focus on user latency and interface responsiveness"
    ]
  }
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "ai-ml",
    number: "01",
    title: "AI & MACHINE LEARNING",
    tagline: "Intelligent systems tailored to your workflows",
    description: "Intelligent solutions that automate processes, analyze data and help businesses make better decisions.",
    iconName: "BrainCircuit",
    capabilities: [
      "Custom LLM & Agent Integrations",
      "Automated Document & Data Pipelines",
      "Predictive Analytics & Forecasting",
      "Intelligent Search & Vector Databases"
    ],
    deliverables: [
      "Production-ready AI microservices",
      "Fine-tuned model inference pipelines",
      "Comprehensive telemetry & evaluation suites"
    ],
    techStack: ["Python", "PyTorch", "Gemini API", "FastAPI", "Vector DBs", "LangChain"]
  },
  {
    id: "web-dev",
    number: "02",
    title: "WEB DEVELOPMENT",
    tagline: "High-performance web platforms",
    description: "Fast, modern and scalable websites and web applications built around your business needs.",
    iconName: "Globe",
    capabilities: [
      "Full-stack Web Applications",
      "High-Conversion Marketing & Product Portals",
      "Headless CMS & E-commerce Platforms",
      "Real-time Dashboards & Interactive Portals"
    ],
    deliverables: [
      "Sub-second page loads with 99+ Core Web Vitals",
      "Fully responsive design for all viewport sizes",
      "Robust API integration and auth security"
    ],
    techStack: ["React", "TypeScript", "Next.js / Vite", "Tailwind CSS", "Node.js", "PostgreSQL"]
  },
  {
    id: "custom-software",
    number: "03",
    title: "CUSTOM SOFTWARE",
    tagline: "Purpose-built software systems",
    description: "Purpose-built software designed to solve specific business challenges and workflows.",
    iconName: "Code2",
    capabilities: [
      "Internal Business Tooling & ERP Systems",
      "API & Microservice Architectures",
      "Workflow & Task Automation Engines",
      "Cloud Infrastructure & DevOps Setup"
    ],
    deliverables: [
      "Modular, maintainable codebase with full documentation",
      "Automated CI/CD pipelines and staging environments",
      "Role-based access control and database optimization"
    ],
    techStack: ["TypeScript", "Go / Python", "Docker", "Google Cloud", "PostgreSQL / Firestore", "GraphQL / REST"]
  },
  {
    id: "ui-ux",
    number: "04",
    title: "UI/UX DESIGN",
    tagline: "Human-centered digital product design",
    description: "Clean, intuitive digital experiences designed around your users.",
    iconName: "Layers",
    capabilities: [
      "Design Systems & Component Libraries",
      "Interactive Prototyping & Wireframing",
      "User Research & Usability Audits",
      "Responsive Web & Mobile App Interfaces"
    ],
    deliverables: [
      "Figma design system tokens and component kit",
      "Clickable interactive prototypes for user testing",
      "Developer handoff specs with exact spatial guidelines"
    ],
    techStack: ["Figma", "Design Tokens", "Material 3 / Google Design", "Tailwind UI", "Micro-animations"]
  }
];

export const WHY_US_DATA: PillarItem[] = [
  {
    title: "Built Around Your Goals",
    description: "We start by understanding the problem before choosing the technology.",
    iconName: "Target",
    badge: "Problem First"
  },
  {
    title: "Modern Engineering",
    description: "We use modern tools and development practices to build reliable products.",
    iconName: "Cpu",
    badge: "Modern Stack"
  },
  {
    title: "Simple & Transparent",
    description: "Clear communication, clear development processes and no unnecessary complexity.",
    iconName: "ShieldCheck",
    badge: "Zero Friction"
  },
  {
    title: "Built to Grow",
    description: "Our solutions are designed with future expansion in mind.",
    iconName: "TrendingUp",
    badge: "Scale Ready"
  }
];

export const PROCESS_DATA: ProcessStep[] = [
  {
    number: "01",
    title: "DISCOVER",
    action: "Understand",
    detail: "We deep dive into your business objectives, operational hurdles, user journeys, and technical constraints.",
    deliverable: "Architecture blueprint & scope breakdown"
  },
  {
    number: "02",
    title: "DESIGN",
    action: "Plan",
    detail: "We engineer wireframes, interactive prototypes, and precise technical system specifications.",
    deliverable: "Design prototype & database schema"
  },
  {
    number: "03",
    title: "BUILD",
    action: "Develop",
    detail: "We implement using clean, typed code, continuous testing, and weekly milestone previews.",
    deliverable: "Functional staged builds & test reports"
  },
  {
    number: "04",
    title: "LAUNCH",
    action: "Deliver",
    detail: "We deploy to high-availability cloud infrastructure, configure monitoring, and provide launch support.",
    deliverable: "Live deployment, docs & source handover"
  }
];

export const CONTACT_DATA = {
  heading: "Have an Idea? Let's Build It.",
  subheading: "Tell us what you're looking to build and let's explore how technology can turn it into reality.",
  ctaButton: "Start a Conversation →",
  email: "hello@hmklabs.com",
  linkedin: "HMK Labs",
  linkedinUrl: "https://www.linkedin.com/company/hmk-labs",
  location: "Pakistan",
  timezone: "PKT (UTC+5)",
};

export const FOOTER_DATA = {
  tagline: "Building technology that moves business forward.",
  copyright: "© 2026 HMK Labs. All Rights Reserved."
};
