import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, ChevronDown, Sparkles } from 'lucide-react';
import { HERO_DATA } from '../data/content';
import { TechGraphic } from './TechGraphic';

interface HeroProps {
  onStartProject: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStartProject }) => {
  const scrollToServices = () => {
    const el = document.getElementById('services');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative pt-32 pb-20 md:pt-40 md:pb-28 lg:pt-44 lg:pb-32 overflow-hidden bg-gradient-to-b from-white via-[#f8f9fa] to-[#f1f5f9]"
    >
      {/* Subtle Sleek Ambient Background Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-blue-100/60 via-indigo-50/30 to-slate-100/40 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline, Description & Actions */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="lg:col-span-7 flex flex-col items-start text-left"
          >
            {/* Status Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200/80 text-blue-700 text-xs font-semibold mb-6 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Technology &amp; Intelligent Software Engineering</span>
            </div>

            {/* Main Heading */}
            <h1
              id="hero-main-heading"
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12] mb-6"
            >
              Building Technology.{' '}
              <span className="text-blue-600 block sm:inline">
                Creating Possibilities.
              </span>
            </h1>

            {/* Description */}
            <p
              id="hero-description"
              className="text-lg sm:text-xl text-slate-600 font-normal leading-relaxed max-w-2xl mb-9"
            >
              {HERO_DATA.subheadline}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
              <button
                id="hero-start-project-btn"
                onClick={onStartProject}
                className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-full text-base font-semibold bg-blue-600 text-white hover:bg-blue-700 active:scale-98 shadow-sm hover:shadow-md hover:shadow-blue-500/20 transition-all duration-200 cursor-pointer"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-explore-services-btn"
                onClick={scrollToServices}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full text-base font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200/90 active:scale-98 shadow-xs hover:shadow-sm transition-all duration-200 cursor-pointer"
              >
                <span>Explore Services</span>
                <ChevronDown className="w-4 h-4 text-slate-500" />
              </button>
            </div>

            {/* Micro Highlights */}
            <div className="mt-10 pt-8 border-t border-slate-200/90 flex flex-wrap items-center gap-6 text-xs text-slate-500 font-medium">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-slate-600">Modern Full-Stack &amp; AI</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-600" />
                <span className="text-slate-600">Custom Software Architecture</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-slate-600">Agile &amp; Transparent Delivery</span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Abstract Technology Graphic */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15, ease: 'easeOut' }}
            className="lg:col-span-5 w-full flex justify-center lg:justify-end"
          >
            <TechGraphic />
          </motion.div>

        </div>
      </div>
    </section>
  );
};
