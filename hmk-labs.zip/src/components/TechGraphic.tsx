import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Cpu, GitBranch, Terminal, ShieldCheck } from 'lucide-react';

export const TechGraphic: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activeMetric, setActiveMetric] = useState(0);

  const metrics = [
    { label: "Architecture", value: "Cloud Native", icon: Cpu, color: "#2563eb" },
    { label: "Neural Engine", value: "Realtime AI", icon: Sparkles, color: "#10b981" },
    { label: "Code Quality", value: "100% Typed", icon: Terminal, color: "#f59e0b" },
    { label: "Deployment", value: "99.9% Uptime", icon: ShieldCheck, color: "#6366f1" }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveMetric((prev) => (prev + 1) % metrics.length);
    }, 3200);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 480);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 440);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };

    window.addEventListener('resize', handleResize);

    // Particle nodes
    const nodeCount = 28;
    const colors = ['#2563eb', '#10b981', '#f59e0b', '#6366f1', '#06b6d4'];
    const nodes: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      color: string;
      pulse: number;
    }> = [];

    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.7,
        vy: (Math.random() - 0.5) * 0.7,
        radius: Math.random() * 2.5 + 2,
        color: colors[i % colors.length],
        pulse: Math.random() * Math.PI * 2,
      });
    }

    // Packet travelers
    const packets: Array<{
      from: number;
      to: number;
      progress: number;
      speed: number;
      color: string;
    }> = [];

    const spawnPacket = () => {
      if (nodes.length < 2) return;
      const from = Math.floor(Math.random() * nodes.length);
      let to = Math.floor(Math.random() * nodes.length);
      while (to === from) to = Math.floor(Math.random() * nodes.length);
      packets.push({
        from,
        to,
        progress: 0,
        speed: 0.008 + Math.random() * 0.012,
        color: nodes[from].color,
      });
    };

    let tick = 0;

    const render = () => {
      tick++;
      if (tick % 45 === 0 && packets.length < 12) {
        spawnPacket();
      }

      ctx.clearRect(0, 0, width, height);

      // Subtle background grid
      ctx.strokeStyle = 'rgba(226, 232, 240, 0.7)';
      ctx.lineWidth = 1;
      const gridSize = 36;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw subtle orbital rings in center
      const centerX = width / 2;
      const centerY = height / 2;
      ctx.strokeStyle = 'rgba(37, 99, 235, 0.08)';
      ctx.lineWidth = 1.5;
      [70, 130, 190].forEach((r, idx) => {
        ctx.beginPath();
        ctx.arc(centerX, centerY, r + Math.sin(tick * 0.02 + idx) * 4, 0, Math.PI * 2);
        ctx.stroke();
      });

      // Update and connect nodes
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        n.x += n.vx;
        n.y += n.vy;
        n.pulse += 0.04;

        if (n.x < 10 || n.x > width - 10) n.vx *= -1;
        if (n.y < 10 || n.y > height - 10) n.vy *= -1;

        // Draw connections
        for (let j = i + 1; j < nodes.length; j++) {
          const n2 = nodes[j];
          const dx = n.x - n2.x;
          const dy = n.y - n2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 110) {
            const alpha = (1 - dist / 110) * 0.28;
            ctx.strokeStyle = `rgba(148, 163, 184, ${alpha})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(n.x, n.y);
            ctx.lineTo(n2.x, n2.y);
            ctx.stroke();
          }
        }
      }

      // Draw data packets
      for (let i = packets.length - 1; i >= 0; i--) {
        const p = packets[i];
        p.progress += p.speed;
        if (p.progress >= 1) {
          packets.splice(i, 1);
          continue;
        }
        const n1 = nodes[p.from];
        const n2 = nodes[p.to];
        if (!n1 || !n2) continue;

        const curX = n1.x + (n2.x - n1.x) * p.progress;
        const curY = n1.y + (n2.y - n1.y) * p.progress;

        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(curX, curY, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // Draw nodes
      nodes.forEach((n) => {
        const currentRadius = n.radius + Math.sin(n.pulse) * 0.8;
        ctx.fillStyle = n.color;
        ctx.beginPath();
        ctx.arc(n.x, n.y, currentRadius, 0, Math.PI * 2);
        ctx.fill();

        // Subtle glow halo
        ctx.fillStyle = `${n.color}15`;
        ctx.beginPath();
        ctx.arc(n.x, n.y, currentRadius * 2.8, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div id="tech-abstract-graphic" className="relative w-full h-[400px] sm:h-[460px] lg:h-[480px] rounded-3xl bg-gradient-to-br from-[#ffffff] via-[#f8fafd] to-[#f1f5f9] border border-slate-200/90 shadow-sm overflow-hidden flex items-center justify-center p-6 select-none">
      {/* Background Interactive Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

      {/* Decorative Core Floating Hologram Card */}
      <div className="relative z-10 w-full max-w-[340px] bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200 shadow-[0_8px_30px_rgb(0,0,0,0.06)] p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
          </div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            HMK Core Logic
          </span>
        </div>

        <div className="py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">System Architecture</div>
              <div className="text-sm font-bold text-slate-900 tracking-tight">
                AI &amp; Scalable Infrastructure
              </div>
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-[11px] font-semibold text-slate-600">
              <span>Operational Efficiency</span>
              <span className="text-blue-600 font-bold">99.8%</span>
            </div>
            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full"
                initial={{ width: "30%" }}
                animate={{ width: "95%" }}
                transition={{ duration: 2, ease: "easeOut" }}
              />
            </div>
          </div>
        </div>

        {/* Dynamic Metric Pill Carousel */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              {React.createElement(metrics[activeMetric].icon, {
                className: "w-4 h-4",
                style: { color: metrics[activeMetric].color }
              })}
              <span className="text-slate-600 font-medium">
                {metrics[activeMetric].label}:
              </span>
            </div>
            <span
              className="font-bold text-xs px-2.5 py-0.5 rounded-full bg-slate-50 border border-slate-200/80"
              style={{ color: metrics[activeMetric].color }}
            >
              {metrics[activeMetric].value}
            </span>
          </div>
        </div>
      </div>

      {/* Floating Accent Badges */}
      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-6 left-6 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/90 backdrop-blur-sm border border-slate-200 shadow-xs text-xs font-semibold text-slate-700"
      >
        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
        <span>Intelligent Pipelines</span>
      </motion.div>

      <motion.div
        animate={{ y: [0, 6, 0] }}
        transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        className="absolute bottom-6 right-6 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/90 backdrop-blur-sm border border-slate-200 shadow-xs text-xs font-semibold text-slate-700"
      >
        <GitBranch className="w-3.5 h-3.5 text-blue-600" />
        <span>Production Grade Code</span>
      </motion.div>
    </div>
  );
};
