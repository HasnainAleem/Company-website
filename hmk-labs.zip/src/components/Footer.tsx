import React from 'react';
import { ArrowUp, Heart } from 'lucide-react';
import { FOOTER_DATA, SERVICES_DATA } from '../data/content';

interface FooterProps {
  onSelectServiceById: (id: string) => void;
  onOpenAboutModal: () => void;
  onOpenContact: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectServiceById,
  onOpenAboutModal,
  onOpenContact,
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="main-footer" className="bg-[#f8f9fa] border-t border-slate-200 text-slate-500 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-12 border-b border-slate-200">
          
          {/* Brand & Slogan Column */}
          <div className="md:col-span-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2.5 mb-4">
                <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
                  H
                </div>
                <span className="font-extrabold text-xl tracking-tight text-slate-900">
                  HMK LABS
                </span>
              </div>
              <p className="text-base text-slate-600 leading-relaxed max-w-sm">
                {FOOTER_DATA.tagline}
              </p>
            </div>

            <div className="mt-8 flex items-center gap-2 text-xs text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Available for new projects &amp; partnerships</span>
            </div>
          </div>

          {/* Services Column */}
          <div className="md:col-span-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-4">
              Services
            </h4>
            <ul className="space-y-3 text-sm">
              {SERVICES_DATA.map((service) => (
                <li key={service.id}>
                  <button
                    onClick={() => {
                      scrollToSection('services');
                      onSelectServiceById(service.id);
                    }}
                    className="hover:text-blue-600 hover:underline transition-colors text-left cursor-pointer"
                  >
                    {service.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Column */}
          <div className="md:col-span-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-4">
              Company
            </h4>
            <ul className="space-y-3 text-sm">
              <li>
                <button
                  onClick={() => {
                    scrollToSection('about');
                    onOpenAboutModal();
                  }}
                  className="hover:text-blue-600 hover:underline transition-colors cursor-pointer"
                >
                  About
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    scrollToSection('contact');
                    onOpenContact();
                  }}
                  className="hover:text-blue-600 hover:underline transition-colors cursor-pointer"
                >
                  Contact
                </button>
              </li>
            </ul>

            <div className="mt-8">
              <button
                onClick={scrollToTop}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 transition-all cursor-pointer shadow-2xs"
              >
                <span>Back to top</span>
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* Copyright Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            {FOOTER_DATA.copyright}
          </div>
          <div className="flex items-center gap-6">
            <span>Built with modern engineering &amp; precision.</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
