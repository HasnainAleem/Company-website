import React from 'react';
import { ArrowRight, BrainCircuit, Globe, Code2, Layers, CheckCircle } from 'lucide-react';
import { SERVICES_DATA } from '../data/content';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'BrainCircuit':
        return <BrainCircuit className="w-6 h-6 text-blue-600" />;
      case 'Globe':
        return <Globe className="w-6 h-6 text-emerald-600" />;
      case 'Code2':
        return <Code2 className="w-6 h-6 text-amber-500" />;
      case 'Layers':
        return <Layers className="w-6 h-6 text-indigo-600" />;
      default:
        return <Code2 className="w-6 h-6 text-blue-600" />;
    }
  };

  const getAccentBg = (index: number) => {
    switch (index) {
      case 0:
        return 'group-hover:border-blue-400 group-hover:shadow-[0_12px_36px_rgba(37,99,235,0.08)]';
      case 1:
        return 'group-hover:border-emerald-400 group-hover:shadow-[0_12px_36px_rgba(16,185,129,0.08)]';
      case 2:
        return 'group-hover:border-amber-400 group-hover:shadow-[0_12px_36px_rgba(245,158,11,0.08)]';
      case 3:
        return 'group-hover:border-indigo-400 group-hover:shadow-[0_12px_36px_rgba(99,102,241,0.08)]';
      default:
        return 'group-hover:border-blue-400';
    }
  };

  return (
    <section id="services" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200/80">
            Core Capabilities
          </span>
          <h2
            id="services-heading"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight mt-4 mb-4"
          >
            Our Services
          </h2>
          <p className="text-lg text-slate-600 font-normal leading-relaxed">
            Focused, high-impact technology solutions built to accelerate business operations and elevate product experiences.
          </p>
        </div>

        {/* 4 Large Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES_DATA.map((service, index) => (
            <div
              key={service.id}
              id={`service-card-${service.id}`}
              className={`group relative bg-white rounded-3xl p-8 sm:p-10 border border-slate-200 transition-all duration-300 flex flex-col justify-between hover:-translate-y-1 ${getAccentBg(
                index
              )}`}
            >
              {/* Card Header: Number & Icon */}
              <div>
                <div className="flex items-center justify-between mb-8">
                  <span className="font-mono text-3xl sm:text-4xl font-extrabold text-slate-200 group-hover:text-slate-400 transition-colors">
                    {service.number}
                  </span>
                  <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-center group-hover:scale-110 group-hover:bg-white transition-all shadow-xs">
                    {getIcon(service.iconName)}
                  </div>
                </div>

                {/* Service Title */}
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mb-3 uppercase">
                  {service.title}
                </h3>

                {/* Service Description */}
                <p className="text-slate-600 text-base leading-relaxed mb-6">
                  {service.description}
                </p>

                {/* Capability Bullet Tags */}
                <div className="space-y-2.5 mb-8">
                  {service.capabilities.slice(0, 3).map((cap, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs sm:text-sm text-slate-700">
                      <CheckCircle className="w-4 h-4 text-blue-600 shrink-0" />
                      <span>{cap}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card Footer: Explore Button */}
              <div className="pt-4 border-t border-slate-100">
                <button
                  id={`service-explore-btn-${service.id}`}
                  onClick={() => onSelectService(service)}
                  className="w-full flex items-center justify-between py-2.5 text-sm font-semibold text-blue-600 group-hover:text-blue-700 transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    Explore Details
                  </span>
                  <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center group-hover:translate-x-1 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
