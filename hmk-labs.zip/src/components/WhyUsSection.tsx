import React from 'react';
import { Target, Cpu, ShieldCheck, TrendingUp } from 'lucide-react';
import { WHY_US_DATA } from '../data/content';

export const WhyUsSection: React.FC = () => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Target':
        return <Target className="w-6 h-6 text-blue-600" />;
      case 'Cpu':
        return <Cpu className="w-6 h-6 text-emerald-600" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-amber-500" />;
      case 'TrendingUp':
        return <TrendingUp className="w-6 h-6 text-indigo-600" />;
      default:
        return <Target className="w-6 h-6 text-blue-600" />;
    }
  };

  return (
    <section id="why-us" className="py-24 md:py-32 bg-[#f8f9fa] border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200/80">
            Our Engineering Philosophy
          </span>
          <h2
            id="why-us-heading"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight mt-4 mb-4"
          >
            Why Work With HMK Labs?
          </h2>
          <p className="text-lg text-slate-600 font-normal leading-relaxed">
            We prioritize long-term software health, clear communication, and purposeful architectural decisions over superficial trends.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHY_US_DATA.map((pillar, idx) => (
            <div
              key={idx}
              id={`why-us-card-${idx}`}
              className="bg-white rounded-3xl p-7 sm:p-8 border border-slate-200/90 shadow-xs hover:shadow-lg hover:shadow-blue-500/5 hover:border-blue-300 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-center shadow-xs">
                    {getIcon(pillar.iconName)}
                  </div>
                  <span className="text-[11px] font-semibold text-slate-600 px-2.5 py-1 rounded-full bg-slate-100">
                    {pillar.badge}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-900 tracking-tight mb-3">
                  {pillar.title}
                </h3>

                <p className="text-sm text-slate-600 leading-relaxed">
                  {pillar.description}
                </p>
              </div>

              <div className="mt-8 pt-4 border-t border-slate-100 flex items-center text-xs font-bold text-blue-600">
                <span>Pillar 0{idx + 1}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
