import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, Award, Compass, Shield, Terminal, ArrowRight } from 'lucide-react';
import { ABOUT_DATA } from '../data/content';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartProject: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({
  isOpen,
  onClose,
  onStartProject,
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/40 backdrop-blur-xs"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden z-10 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-6 sm:p-8 bg-gradient-to-r from-slate-50 to-blue-50/50 border-b border-slate-200 flex items-start justify-between">
            <div>
              <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                HMK Labs Profile
              </span>
              <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
                More About HMK Labs
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-white/80 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-slate-700">
            {/* Core Mission */}
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 mb-2">
                <Compass className="w-4 h-4" />
                <span>Our Mission</span>
              </div>
              <p className="text-base text-slate-900 font-medium leading-relaxed">
                {ABOUT_DATA.extendedDetails.mission}
              </p>
            </div>

            {/* Engineering Approach */}
            <div className="p-5 rounded-2xl bg-[#f8f9fa] border border-slate-200">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-600 mb-2">
                <Terminal className="w-4 h-4" />
                <span>Engineering Philosophy</span>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed">
                {ABOUT_DATA.extendedDetails.approach}
              </p>
            </div>

            {/* Operating Tenets */}
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-900 mb-3">
                <Shield className="w-4 h-4 text-blue-600" />
                <span>Core Operating Principles</span>
              </div>
              <div className="space-y-2.5">
                {ABOUT_DATA.extendedDetails.values.map((v, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white border border-slate-200/90 text-xs font-medium text-slate-900">
                    <div className="w-5 h-5 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer CTA */}
          <div className="p-6 bg-slate-50/80 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-slate-500 font-medium">
              Ready to explore possibilities together?
            </span>
            <button
              onClick={() => {
                onClose();
                onStartProject();
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold bg-blue-600 text-white hover:bg-blue-700 transition-colors cursor-pointer shadow-xs"
            >
              <span>Start a Project</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
