import React from 'react';
import { ArrowRight, CheckCircle2, Award, Zap, Code } from 'lucide-react';
import { ABOUT_DATA } from '../data/content';

interface AboutSectionProps {
  onOpenAboutModal: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenAboutModal }) => {
  return (
    <section id="about" className="py-20 md:py-28 bg-[#f8f9fa] border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          
          {/* Section Label */}
          <div className="text-center sm:text-left mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200/80">
              About HMK Labs
            </span>
          </div>

          {/* Heading */}
          <h2
            id="about-main-heading"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight mb-6"
          >
            {ABOUT_DATA.heading}
          </h2>

          {/* Description */}
          <p
            id="about-description"
            className="text-lg sm:text-xl text-slate-600 font-normal leading-relaxed mb-8"
          >
            {ABOUT_DATA.description}
          </p>

          {/* Key Value Micro Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 my-8">
            {ABOUT_DATA.pillarsSummary.map((item, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:border-blue-400 hover:shadow-md hover:shadow-blue-500/5 transition-all duration-200"
              >
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                  {idx === 0 && <Code className="w-4 h-4" />}
                  {idx === 1 && <Zap className="w-4 h-4" />}
                  {idx === 2 && <Award className="w-4 h-4" />}
                </div>
                <h3 className="text-sm font-bold text-slate-900 mb-1">
                  {item.label}
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>

          {/* More About Link */}
          <div className="pt-2">
            <button
              id="about-more-link"
              onClick={onOpenAboutModal}
              className="group inline-flex items-center gap-2 text-base font-semibold text-blue-600 hover:text-blue-700 transition-colors cursor-pointer"
            >
              <span>{ABOUT_DATA.linkText}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};
