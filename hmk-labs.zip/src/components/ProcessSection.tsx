import React from 'react';
import { ArrowRight, Compass, PencilRuler, Code, Rocket } from 'lucide-react';
import { PROCESS_DATA } from '../data/content';

export const ProcessSection: React.FC = () => {
  const getStepIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Compass className="w-5 h-5 text-blue-600" />;
      case 1:
        return <PencilRuler className="w-5 h-5 text-emerald-600" />;
      case 2:
        return <Code className="w-5 h-5 text-amber-500" />;
      case 3:
        return <Rocket className="w-5 h-5 text-indigo-600" />;
      default:
        return <Compass className="w-5 h-5 text-blue-600" />;
    }
  };

  return (
    <section id="process" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200/80">
            Methodology
          </span>
          <h2
            id="process-heading"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight mt-4 mb-4"
          >
            From Idea to Reality
          </h2>
          <p className="text-lg text-slate-600 font-normal leading-relaxed">
            A structured, repeatable engineering pipeline that turns ambitious concepts into dependable digital products.
          </p>
        </div>

        {/* Horizontal Process Stepper Grid */}
        <div className="relative">
          {/* Connecting Line behind items on desktop */}
          <div className="hidden lg:block absolute top-1/2 left-8 right-8 h-0.5 bg-gradient-to-r from-blue-200 via-emerald-200 to-indigo-200 -translate-y-6 z-0" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
            {PROCESS_DATA.map((step, idx) => (
              <div
                key={step.number}
                id={`process-step-${step.number}`}
                className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xs hover:shadow-lg hover:shadow-blue-500/5 hover:border-blue-300 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Step Top Bar */}
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-mono text-2xl font-black text-blue-600">
                      {step.number}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-center shadow-xs">
                      {getStepIcon(idx)}
                    </div>
                  </div>

                  {/* Step Title & Action */}
                  <div className="mb-3">
                    <h3 className="text-lg font-bold text-slate-900 uppercase tracking-wider">
                      {step.title}
                    </h3>
                    <span className="inline-block text-xs font-semibold text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-md mt-1 border border-blue-100">
                      {step.action}
                    </span>
                  </div>

                  {/* Step Detail */}
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
                    {step.detail}
                  </p>
                </div>

                {/* Deliverable */}
                <div className="pt-3 border-t border-slate-100">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Key Outcome
                  </div>
                  <div className="text-xs font-medium text-slate-800">
                    {step.deliverable}
                  </div>
                </div>

                {/* Desktop Arrow Indicator on non-last steps */}
                {idx < PROCESS_DATA.length - 1 && (
                  <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-6 z-20 w-6 h-6 rounded-full bg-white border border-slate-200 items-center justify-center text-slate-500 shadow-xs">
                    <ArrowRight className="w-3 h-3" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
