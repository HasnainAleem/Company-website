export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  tagline: string;
  description: string;
  iconName: string;
  capabilities: string[];
  deliverables: string[];
  techStack: string[];
}

export interface PillarItem {
  title: string;
  description: string;
  iconName: string;
  badge: string;
}

export interface ProcessStep {
  number: string;
  title: string;
  action: string;
  detail: string;
  deliverable: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  serviceInterest: string;
  budgetRange: string;
  message: string;
}
